// client/src/App.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TaskList from './components/TaskList';
import AddTask from './components/AddTask';

const App = () => {
    const [tasks, setTasks] = useState([]);

    useEffect(() => {
        axios.get('/api/tasks')
            .then(res => setTasks(res.data))
            .catch(err => console.log(err));
    }, []);

    const handleAdd = task => {
        axios.post('/api/tasks', task)
            .then(res => setTasks([...tasks, res.data]))
            .catch(err => console.log(err));
    };

    const handleDelete = id => {
        axios.delete(`/api/tasks/${id}`)
            .then(() => setTasks(tasks.filter(task => task._id !== id)))
            .catch(err => console.log(err));
    };

    const handleUpdate = (id, updatedTask) => {
        axios.patch(`/api/tasks/${id}`, updatedTask)
            .then(res => {
                setTasks(tasks.map(task => {
                    if (task._id === id) {
                        return res.data;
                    }
                    return task;
                }));
            })
            .catch(err => console.log(err));
    };

    return (
        <div>
            <h1>Task Manager</h1>
            <AddTask onAdd={handleAdd} />
            <TaskList tasks={tasks} onDelete={handleDelete} onUpdate={handleUpdate} />
        </div>
    );
};

export default App;
