// client/src/components/Task.js

import React, { useState } from 'react';

const Task = ({ task, onDelete, onUpdate }) => {
    const [editing, setEditing] = useState(false);
    const [title, setTitle] = useState(task.title);
    const [description, setDescription] = useState(task.description);

    const handleDelete = () => {
        onDelete(task._id);
    };

    const handleUpdate = () => {
        onUpdate(task._id, { title, description });
        setEditing(false);
    };

    return (
        <div>
            {editing ? (
                <div>
                    <input type="text" value={title} onChange={e => setTitle(e.target.value)} />
                    <input type="text" value={description} onChange={e => setDescription(e.target.value)} />
                    <button onClick={handleUpdate}>Update</button>
                </div>
            ) : (
                <div>
                    <h3>{task.title}</h3>
                    <p>{task.description}</p>
                    <button onClick={() => setEditing(true)}>Edit</button>
                    <button onClick={handleDelete}>Delete</button>
                </div>
            )}
        </div>
    );
};

export default Task;
